# Fonti prodotto Relife Battery

Fonti online usate per verificare modelli, anni e tipologia veicolo. Le specifiche batteria, il numero moduli e i prezzi vengono dalla tua tabella interna.

## Toyota

- Yaris 2012-2019: <https://en.wikipedia.org/wiki/Toyota_Yaris>
- Prius II 2004-2009: <https://en.wikipedia.org/wiki/Toyota_Prius_(XW20)>
- Prius III 2009-2016: <https://en.wikipedia.org/wiki/Toyota_Prius_(XW30)>
- Prius IV 2016-2022: <https://en.wikipedia.org/wiki/Toyota_Prius_(XW50)>
- Auris 2010-2019: <https://en.wikipedia.org/wiki/Toyota_Auris>
- C-HR 2016-2019: <https://en.wikipedia.org/wiki/Toyota_C-HR>
- Corolla 2019-2023: <https://en.wikipedia.org/wiki/Toyota_Corolla>
- Crown 2009-2016: <https://en.wikipedia.org/wiki/Toyota_Crown>
- Highlander II 2005-2019: <https://en.wikipedia.org/wiki/Toyota_Highlander>
- RAV4 2012-2018: <https://en.wikipedia.org/wiki/Toyota_RAV4>
- Camry 2006-2017: <https://en.wikipedia.org/wiki/Toyota_Camry>

## Lexus

- CT 200h 2010-2012: <https://en.wikipedia.org/wiki/Lexus_CT>
- UX 250h 2019-oggi: <https://en.wikipedia.org/wiki/Lexus_UX>
- IS 300h 2013-2019: <https://en.wikipedia.org/wiki/Lexus_IS>
- GS 300h / GS 450h: <https://en.wikipedia.org/wiki/Lexus_GS>
- NX 300h 2014-2021: <https://en.wikipedia.org/wiki/Lexus_NX>

## Nota immagini

Per evitare hotlink instabili o immagini con licenza incerta dentro Shopify, il tema e il CSV sono pronti per prodotti con immagine caricata nello store. Le pagine online sopra includono immagini di riferimento utili per recuperare la foto corretta del modello da caricare nel prodotto Shopify.
